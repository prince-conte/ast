  ymaps.ready(function () {  
    var map = new ymaps.Map("mapy", {
          center: [55.76, 37.64], 
          zoom: 10
        });
  });